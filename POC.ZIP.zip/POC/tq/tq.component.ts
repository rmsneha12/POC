import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tq',
  templateUrl: './tq.component.html',
  styleUrls: ['./tq.component.css']
})
export class TqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
