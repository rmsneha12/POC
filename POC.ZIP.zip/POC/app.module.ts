import { DataService } from './data.service';
import { AuthService } from './auth.service';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { DetComponent } from './det/det.component';
import { TqComponent } from './tq/tq.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DetComponent,
    TqComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path:'login',
        component:LoginComponent
      },
      {
        path:'details',
        component:DetComponent
      },
      {
        path:'thankyou',
        component:TqComponent
      },
      {
        path: '',
        component:HomeComponent
      },
    ])
  ],
  providers: [
    DataService
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
