import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-det',
  templateUrl: './det.component.html',
  styleUrls: ['./det.component.css']
})
export class DetComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  goToPage(pagename:string){
    this.router.navigate([pagename]);
  }
  }


