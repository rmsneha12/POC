import { HttpClient } from '@angular/common/http';
import { DataService } from './../data.service';
import { AuthService } from './../auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup,FormControl} from '@angular/forms';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username;
  constructor(private http:HttpClient, private service: DataService, private auth: AuthService,private router:Router,private dataserv: DataService) { }
  getUsers(): Observable<UserData[]> {
    return this.http.get<UserData[]>(this.apiurl).pipe(
      tap(data => console.log(data))
    );
  ngOnInit() {
    
  }
 gotopage(pagename:string){
   this.router.navigate([pagename])
 }
 
 }

